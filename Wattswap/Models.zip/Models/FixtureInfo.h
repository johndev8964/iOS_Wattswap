//
//  FixtureInfo.h
//  Wattswap
//
//  Created by MY on 8/28/15.
//  Copyright (c) 2015 Liming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface FixtureInfo : NSManagedObject

@property (nonatomic, retain) NSNumber * aid;
@property (nonatomic, retain) NSString * answer;
@property (nonatomic, retain) NSString * answerbulbs;
@property (nonatomic, retain) NSString * ballastfactor;
@property (nonatomic, retain) NSString * ballasttype;
@property (nonatomic, retain) NSString * bulbsvalue;
@property (nonatomic, retain) NSString * code;
@property (nonatomic, retain) NSString * control;
@property (nonatomic, retain) NSNumber * fid;
@property (nonatomic, retain) NSString * fixturecnt;
@property (nonatomic, retain) NSNumber * fixtureid;
@property (nonatomic, retain) NSString * fixturename;
@property (nonatomic, retain) NSString * fvalue;
@property (nonatomic, retain) NSString * height;
@property (nonatomic, retain) NSString * mounting;
@property (nonatomic, retain) NSString * note;
@property (nonatomic, retain) NSNumber * ofp_aid;
@property (nonatomic, retain) NSNumber * ofp_fid;
@property (nonatomic, retain) NSNumber * ofp_fixtureid;
@property (nonatomic, retain) NSString * ofp_path;
@property (nonatomic, retain) NSNumber * ofp_sid;
@property (nonatomic, retain) NSString * option;
@property (nonatomic, retain) NSString * path;
@property (nonatomic, retain) NSNumber * sid;
@property (nonatomic, retain) NSString * style;
@property (nonatomic, retain) NSString * supervisor_id;
@property (nonatomic, retain) NSString * svalue;
@property (nonatomic, retain) NSString * wattsvalue;
@property (nonatomic, retain) NSDate * stime;
@property (nonatomic, retain) NSNumber * replacement_id;

- (void)initWithDict:(NSDictionary*)dic;

@end
