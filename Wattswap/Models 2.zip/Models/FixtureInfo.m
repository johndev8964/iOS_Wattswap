//
//  FixtureInfo.m
//  Wattswap
//
//  Created by MY on 8/28/15.
//  Copyright (c) 2015 Liming. All rights reserved.
//

#import "FixtureInfo.h"


@implementation FixtureInfo

@dynamic aid;
@dynamic answer;
@dynamic answerbulbs;
@dynamic ballastfactor;
@dynamic ballasttype;
@dynamic bulbsvalue;
@dynamic code;
@dynamic control;
@dynamic fid;
@dynamic fixturecnt;
@dynamic fixtureid;
@dynamic fixturename;
@dynamic fvalue;
@dynamic height;
@dynamic mounting;
@dynamic note;
@dynamic ofp_aid;
@dynamic ofp_fid;
@dynamic ofp_fixtureid;
@dynamic ofp_path;
@dynamic ofp_sid;
@dynamic option;
@dynamic path;
@dynamic sid;
@dynamic style;
@dynamic supervisor_id;
@dynamic svalue;
@dynamic wattsvalue;
@dynamic stime;
@dynamic replacement_id;
@dynamic seq;

- (void)initWithDict:(NSDictionary*)dic {
    
    Global *global = [Global sharedManager];
    self.sid = NFS([dic objectForKey:@"survey_id"]);
    self.fid = NFS([dic objectForKey:@"floor_id"]);
    self.aid = NFS([dic objectForKey:@"area_id"]);
    
    self.fixtureid = NFS([dic objectForKey:@"fixture_id"]);
    self.fixturename = [dic objectForKey:@"type"];
    self.fixturecnt = [dic objectForKey:@"count"];
    self.code = [dic objectForKey:@"code"];
    self.style = [dic objectForKey:@"style"];
    self.mounting = [dic objectForKey:@"mounting"];
    self.option = [dic objectForKey:@"option"];
    self.control = [dic objectForKey:@"controlled"];
    self.height = [dic objectForKey:@"height"];
    self.note = [dic objectForKey:@"notes"];
    self.fvalue = [dic objectForKey:@"hrs_per_day"];
    self.svalue = [dic objectForKey:@"days_per_week"];
    self.answer = [NSString stringWithFormat:@"%d", [self.fvalue intValue] * [self.svalue intValue] * 52];
    self.bulbsvalue = [dic objectForKey:@"bulbs_per_fixture"];
    self.wattsvalue = [dic objectForKey:@"watts_per_bulb"];
    self.answerbulbs = [NSString stringWithFormat:@"%d", [self.bulbsvalue intValue] * [self.wattsvalue intValue] * 52];
    self.ballasttype = [dic objectForKey:@"ballast"];
    self.ballastfactor = [dic objectForKey:@"factor"];
    self.seq = [dic objectForKey:@"seq"];
    
    if (ISNull([dic objectForKey:@"fixture_image"])) {
        self.path = @"";
    }
    else {
        self.path = [dic objectForKey:@"fixture_image"];
    }
    
    self.replacement_id = NFS([dic objectForKey:@"replacement_id"]);
    NSString *lastModified = [dic objectForKey:@"create_ts"];
    self.stime = [global getDateFromString:lastModified Format:@"yyyy-MM-dd HH:mm:ss"];
}

@end
