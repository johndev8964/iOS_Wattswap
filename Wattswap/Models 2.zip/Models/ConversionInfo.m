//
//  ConversionInfo.m
//  Wattswap
//
//  Created by MY on 8/28/15.
//  Copyright (c) 2015 Liming. All rights reserved.
//

#import "ConversionInfo.h"


@implementation ConversionInfo

@dynamic conversion_id;
@dynamic fixture_code;
@dynamic fixture_input_watt;
@dynamic fixture_name;
@dynamic fixture_type;
@dynamic image_path;
@dynamic lamp_ballast_type;
@dynamic retrofit_desc;

@end
